# paper-review-on-cloud-computing-trends
Paper review on Cloud computing and emerging IT platforms: Vision, hype, and reality for delivering computing as the 5th utility. 
This has a docx file which is my review of the paper . A powerpoint which explains the paper and the base paper. 
